﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 123456;

            Console.WriteLine("base int: " + num);

            Console.Write("reversre digits: ");
            Console.WriteLine(num.ReverseDigits());

            Console.Write("sum digits: ");
            Console.WriteLine(num.SumDigits());

            Console.WriteLine("random position: ");
            Console.WriteLine(num.RandomDigits());

            Console.Write("int to list of string: ");

            foreach (var item in num.ToList<string>())
            {
                Console.Write(item + "\t");
            }

            Console.WriteLine();

            DictionaryList<char, int> col = new DictionaryList<char, int>();

            col.Add(1);
            col.Add(2);
            col.Add(3);

            col.Add('a', (int)'a');
            col.Add('b', (int)'b');
            col.Add('c', (int)'c');

            Console.WriteLine("enumerate collection values: ");

            foreach (var item in col)
            {
                Console.Write(item + "\t");
            }

            Console.WriteLine();

            var keys = col.Keys;

            Console.WriteLine("collections keys:");
            foreach (var key in keys)
            {
                Console.Write(key + "\t");
            }


            Console.WriteLine();

            var values = col.Values;

            Console.WriteLine("collections values:");
            foreach (var value in values)
            {
                Console.Write(value + "\t");
            }

            Console.WriteLine();

            Console.WriteLine("get element by key 'b': " + col['b']);
            Console.WriteLine("get element b index 2: " + col[2]);
            Console.WriteLine("ContainsKey method for 'a': " + col.ContainsKey('a'));

            Console.WriteLine("remove element with key 'c'");
            col.Remove('c');
            foreach (var item in col.Keys)
            {
                Console.Write(item + "\t");
            }
        }
    }
}
