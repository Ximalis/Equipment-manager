﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace T3
{
    static class IntExtensions
    {
        public static int ReverseDigits(this int num)
        {
            char[] digits = num.ToString().ToCharArray();

            return int.Parse(new string(digits.Reverse().ToArray()));
        }

        public static int SumDigits(this int num)
        {
            char[] digits = num.ToString().ToCharArray();

            int sum = 0;

            foreach (char d in digits)
            {
                sum += int.Parse(d.ToString());
            }

            return sum;
        }

        public static int RandomDigits(this int num)
        {
            Random rnd = new Random();
            char[] digits = num.ToString().ToCharArray().OrderBy(d => rnd.Next()).ToArray();

            return int.Parse(new string(digits));
        }

        public static List<T> ToList<T>(this int num)
        {
            List<T> list = new List<T>();
            char[] digits = num.ToString().ToCharArray();

            foreach (char d in digits)
            {
                list.Add((T)Convert.ChangeType(d, typeof(T)));
            }

            return list;
        }
    }
}
