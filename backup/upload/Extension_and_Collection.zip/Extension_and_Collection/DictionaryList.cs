﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace T3
{
    class DictionaryList<TKey, T> : ICollection<T>, IDictionary<TKey, T>
    {
        private int count = 0;
        private int keys_count = 0;
        private T[] items;

        private KeyValuePair<TKey, T>[] keys_values;

        public int Count
        {
            get
            {
                return count;
            }
        }

        public bool IsReadOnly
        {
            get
            {
                return false;
            }
        }

        public ICollection<TKey> Keys
        {
            get
            {
                TKey[] keys = new TKey[keys_values.Length];

                for (int i = 0; i < keys_values.Length; i++)
                {
                    keys[i] = keys_values[i].Key;
                }

                return keys;
            }
        }

        public ICollection<T> Values
        {
            get
            {
                T[] values = new T[keys_values.Length];

                for (int i = 0; i < keys_values.Length; i++)
                {
                    values[i] = keys_values[i].Value;
                }

                return values;
            }
        }

        public T this[TKey key]
        {
            get
            {
                KeyValuePair<TKey, T> v = keys_values.Where(k => EqualityComparer<TKey>.Default.Equals(k.Key, key))
                    .First();

                return v.Value;
            }

            set
            {
                for (int i = 0; i < keys_values.Length; i++)
                {
                    if(EqualityComparer<TKey>.Default.Equals(keys_values[i].Key, key))
                    {
                        KeyValuePair<TKey, T> v = new KeyValuePair<TKey, T>(key, value);
                        keys_values[i] = v;
                    }
                }
            }
        }

        public T this[int idx]
        {
            get
            {
                return items[idx];
            }
            set { Add(value); }
        }

        public void Add(T item)
        {
            AddItem(item);
        }

        private void ArrayResize<T1>(ref T1[] arr)
        {
            T1[] n_arr = new T1[arr.Length + 1];

            for (int i = 0; i < arr.Length; i++)
            {
                n_arr[i] = arr[i];
            }

            arr = new T1[arr.Length + 1];
            arr = n_arr;
        }

        public void Clear()
        {
            count = 0;
            items = null;
        }

        public bool Contains(T item)
        {
            for (int i = 0; i < items.Length; i++)
            {
                if (items[i].Equals(item))
                    return true;
            }

            return false;
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            for (int i = arrayIndex, j = 0; j < items.Length; j++)
            {
                array[i + j] = items[j];
            }
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < items.Length + keys_values.Length; i++)
            {
                if (i > items.Length - 1)
                    yield return keys_values[i - items.Length].Value;
                else
                    yield return items[i];
            }
        }

        public bool Remove(T item)
        {
            if (!items.Contains(item))
                return false;

            int s_idx = IndexOf(item);

            if (s_idx != -1)
            {
                T[] arr = new T[items.Length - 1];

                for (int i = 0; i < s_idx; i++)
                {
                    arr[i] = items[i];
                }

                for (int i = s_idx + 1; i < items.Length; i++)
                {
                    arr[i - 1] = items[i];
                }

                items = new T[arr.Length];
                items = arr;

                count--;

                return true;
            }
            else return false;
        }

        public int IndexOf(T item)
        {
            for (int i = 0; i < items.Length; i++)
            {
                if (items[i].Equals(item))
                    return i;
            }

            return -1;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public bool ContainsKey(TKey key)
        {
            if (IndexOfKey(key) != -1)
                return true;

            return false;
        }

        public void Add(TKey key, T value)
        {
            //AddItem(value);
            AddKeyValue(key, value);
        }

        private void AddItem(T value)
        {
            if (count == 0)
                items = new T[1];
            else
                ArrayResize(ref items);

            items[count] = value;
            count++;
        }

        private void AddKeyValue(TKey key, T value)
        {
            if (keys_count == 0)
            {
                keys_values = new KeyValuePair<TKey, T>[1];
            }
            else ArrayResize(ref keys_values);

            KeyValuePair<TKey, T> kv = new KeyValuePair<TKey, T>(key, value);
            keys_values[keys_count] = kv;

            keys_count++;         
        }

        public bool Remove(TKey key)
        {
            int idx = IndexOfKey(key);

            if(idx != -1)
            {
                KeyValuePair<TKey, T>[] n_keys_values = keys_values;
                keys_values = new KeyValuePair<TKey, T>[keys_values.Length - 1];

                for (int i = 0; i < idx; i++)
                {
                    keys_values[i] = n_keys_values[i];
                }

                for (int i = idx + 1; i < n_keys_values.Length; i++)
                {
                    keys_values[i - 1] = n_keys_values[i];
                }

                return true;
            }

            return false;
        }

        private int IndexOfKey(TKey key)
        {
            for (int i = 0; i < keys_values.Length; i++)
            {
                if (EqualityComparer<TKey>.Default.Equals(keys_values[i].Key, key))
                    return i;
            }

            return -1;
        }

        public bool TryGetValue(TKey key, out T value)
        {
            try
            {
                value = keys_values.Where(k => EqualityComparer<TKey>.Default.Equals(k.Key, key))
                          .First().Value;

                return true;
            }
            catch
            {
                value = default(T);
                return false;
            }
        }

        public void Add(KeyValuePair<TKey, T> item)
        {
            AddKeyValue(item.Key, item.Value);
        }

        public bool Contains(KeyValuePair<TKey, T> item)
        {
            if (keys_values.Contains(item)) return true;
            else return false;
        }

        public void CopyTo(KeyValuePair<TKey, T>[] array, int arrayIndex)
        {
            Array.Copy(keys_values, arrayIndex, array, 0, array.Length);
        }

        public bool Remove(KeyValuePair<TKey, T> item)
        {
            return Remove(item.Key);
        }

        IEnumerator<KeyValuePair<TKey, T>> IEnumerable<KeyValuePair<TKey, T>>.GetEnumerator()
        {
            foreach (KeyValuePair<TKey, T> item in keys_values)
            {
                yield return item;
            }
        }
    }
}
