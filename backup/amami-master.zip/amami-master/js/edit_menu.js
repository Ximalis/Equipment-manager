
function onIntEditButtonClicked() {
    display(".list_choise", false);
    display("#content", false);
    
    display("#header", true);
    display("#sub_content", true);
    
    $("#actual_data").html("<div class = 'sub_id'>int</div>");
    
    var inters = getTableData("interests");
    for(var i = 0; i < inters.length; i++) {
        
        var interBlock = [
            "<div class = 'interest'>",
                "<div class = 'num'>" + inters[i]["id"] + "</div>",
                inters[i]["name"] + "",
                "<button class = 'txt_btn del_int_btn'>delete</button><br>",
            "</div>"
        ];
        
        $("#actual_data").append(interBlock.join(""));
    }
}

function onEntEditButtonClicked() {
    display(".list_choise", false);
    display("#content", false);
    
    display("#header", true);
    display("#sub_content", true);
    
    $("#actual_data").html("<div class = 'sub_id'>ent</div>");
    
    var inters = getTableData("interests");
    var enters = getTableData("enterprises");
    
    for(var i = 0; i < enters.length; i++) {
        
        var interIdx = findIdxForId(inters,
            enters[i]["interest_id"]);
            
        var enterBlock = [
            "<div class = 'enterprise'>",
                "<div class = 'num'>" + enters[i]["id"] + "</div>",
                enters[i]["name"] + ":",
                "<button class = 'txt_btn del_ent_btn'>delete</button><br>",
                
                "<div class = 'left'>",
                    "<div class = 'left_tag'>address</div>",
                    "<div class = 'left_data'>" + enters[i]["address"] + "</div>",
                "</div>",
                
                "<div class = 'right'>",
                    "<div class = 'right_tag'>interest</div>",
                    "<div class = 'right_data'>" + inters[interIdx]["name"] + "</div>",
                "</div>",
                
                "<hr>",
            "</div>"
        ];
        
        $("#actual_data").append(enterBlock.join(""));
    }
}

function onPerEditButtonClicked() {
    display(".list_choise", false);
    display("#content", false);
    
    display("#header", true);
    display("#sub_content", true);
    
    $("#actual_data").html("<div class = 'sub_id'>per</div>");
    
    var inters = getTableData("interests");
    var enters = getTableData("enterprises");
    var persons = getTableData("persons");
    
    for(var i = 0; i < persons.length; i++) {
        
        var enterIdx = findIdxForId(enters,
            persons[i]["enterprise_id"]);
            
        var fullName = persons[i]["surname"]    + " " +
                       persons[i]["name"]       + " " +
                       persons[i]["first_name"];
        
        var perBlock = [
            "<div class = 'person'>",
                "<div class = 'num'>" + persons[i]["id"] + "</div>",
                fullName + ":",
                "<button class = 'txt_btn del_per_btn'>delete</button><br>",
                
                "<div class = 'left'>",
                    "<div class = 'left_tag'>mail</div>",
                    "<div class = 'left_data'>" + persons[i]["mail"] + "</div>",
                
                    "<div class = 'left_tag'>enterprise</div>",
                    "<div class = 'left_data'>" + enters[enterIdx]["name"] + "</div>",
                "</div>",
                
                "<div class = 'right'>",
                    "<div class = 'right_tag'>phone</div>",
                    "<div class = 'right_data'>" + persons[i]["phone"] + "</div>",
                    
                    "<div class = 'right_tag'>skype</div>",
                    "<div class = 'right_data'>" + persons[i]["skype"] + "</div>",
                "</div>",
                
                "<hr>",
            "</div>"
        ];
        
        $("#actual_data").append(perBlock.join(""));
    }
}

