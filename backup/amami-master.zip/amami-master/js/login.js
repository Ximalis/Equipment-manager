
function onLogButtonClicked() {
    $("#log_menu").css("color", "#961c00");
    $("#reg_menu").css("color", "#575757");
    
    $("#reg_part").css("display", "none");
    $("#login_part").css("display", "block");
    
    $("#log_info").html("");
    
    $("#reg_name").val("");
    $("#reg_pass").val("");
    $("#reg_conf").val("");
    $("#reg_mail").val("");
    
    if(!$("#log_name").val().length) {
        return;
    }
    
    var name = $("#log_name").val();
    var passwd = hex_sha512($("#log_pass").val());
    
    var req = new XMLHttpRequest();
    req.open("POST", "../php/do_login.php", false);
    req.setRequestHeader("Content-type",
        "application/x-www-form-urlencoded");
        
    req.send("passwd=" + passwd +
             "&name=" + name);
    
    if(parseInt(req.responseText) == 0) {
        window.open("main.php", "_self");
    } else {
        $("#log_info").html(req.responseText);
    }
    
    $("#log_name").val("");
    $("#log_pass").val("");
}

function onRegButtonClicked() {
    $("#reg_menu").css("color", "#961c00");
    $("#log_menu").css("color", "#575757");
    
    $("#login_part").css("display", "none");
    $("#reg_part").css("display", "block");
    
    $("#log_info").html("");
    
    $("#log_name").val("");
    $("#log_pass").val("");
    
    if(!$("#reg_name").val().length) {
        return;
    }
    
    var name = $("#reg_name").val();
    var mail = $("#reg_mail").val();
    
    var passwd1 = hex_sha512($("#reg_pass").val());
    var passwd2 = hex_sha512($("#reg_conf").val());
    
    if(mail == "") {
        $("#log_info").html("Mail can not be empty!");
        return;
    }
    
    if(passwd1 != passwd2) {
        $("#log_info").html("Passwords don't match!");
        return;
    }
    
    var req = new XMLHttpRequest();
    req.open("POST", "../php/register.php", false);
    req.setRequestHeader("Content-type",
        "application/x-www-form-urlencoded");
        
    req.send("passwd=" + passwd1 +
             "&name="  + name +
             "&mail="  + mail);
    
    $("#log_info").html(req.responseText);
    
    $("#reg_name").val("");
    $("#reg_pass").val("");
    $("#reg_conf").val("");
    $("#reg_mail").val("");
}

$(function() {
    $("#log_menu").click(onLogButtonClicked);
    $("#reg_menu").click(onRegButtonClicked);
});
