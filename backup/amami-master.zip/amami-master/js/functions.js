
function getTableData(tableName) {
    var req = new XMLHttpRequest();
    req.open("GET", "../php/get_table.php?name=" + tableName, false);
    req.send(null);

    try {
        return JSON.parse(req.responseText);
    } catch(e) {
        return [];
    }
}

function findIdxForId(hashMapArray, id) {
    for(var i = 0; i < hashMapArray.length; i++) {
        if(hashMapArray[i]["id"] == id) {
            return i;
        }
    }

    return -1;
}

function display(what, isVisible) {
    if(isVisible) {
        $(what).css("display", "block");
    } else {
        $(what).css("display", "none");
    }
}

function displayAll(isVisible) {
    if(isVisible) {
        $("#content").css("display", "block");
        $("#header").css("display", "block");
    } else {
        $("#content").css("display", "none");
        $("#header").css("display", "none");
    }
    
    $("#sub_content").css("display", "none");
}
