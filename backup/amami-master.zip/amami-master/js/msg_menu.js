
function onDetailsMenuButtonClicked() {
    
    if($(this).text() == "details") {
        $(this).text("hide");
            
        $(this).parent().prev().children(".left")
            .children(".adv").css("display", "block");
        
        $(this).parent().prev().children(".right")
            .children(".adv").css("display", "block");
        
    } else {
        $(this).text("details");
        
        $(this).parent().prev().children(".left")
            .children(".adv").css("display", "none");
        
        $(this).parent().prev().children(".right")
            .children(".adv").css("display", "none");
    }
}

function onCanButtonClicked() {
    $(".editor").css("display", "none");
    var subId = $(".sub_id").text();
    
    if(subId == "int") {
        $("#int_text").val("interest");
        
    } else if(subId == "ent") {
        $("#ent_name").val("name");
        $("#ent_address").val("address");
        
        $("#sel_int").text("select interest");
        
    } else if(subId == "per") {
        $("#per_surname").val("surname");
        $("#per_name").val("name");
        $("#per_first_name").val("first name");
        $("#per_mail").val("mail");
        $("#per_skype").val("skype");
        $("#per_phone").val("phone");
        
        $("#sel_ent").text("select enterprise");
        
    } else {
        $("#con_date").val("date");
        $("#con_time").val("time");
        $("#con_goal").val("goal");
        $("#con_result").val("result");
        
        $("#sel_per").text("select person");
        
        display("#sub_content", false);
    }
}

function onAddMenuButtonClicked() {
    onCanButtonClicked();
    var subId = $(".sub_id").text();
    
    if(subId == "int") {
        $("#int_editor").css("display", "block");
        
    } else if(subId == "ent") {
        $("#ent_editor").css("display", "block");
        
    } else if(subId == "per") {
        $("#per_editor").css("display", "block");
        
    } else {
        display("#sub_content", true);
        $("#con_editor").css("display", "block");
    }
}

function callIntOkContext() {
    var inter = $("#int_text").val();
    onCanButtonClicked();
    
    if(inter == "" || inter == "interest") {
        $("#actual_data").html("<div class = 'sub_id'>int</div>");
        $("#actual_data").append("Fields can not be empty!");
        $("#actual_data").css("color", "#961c00");
        
        return;
    }
    
    var req = new XMLHttpRequest();
    req.open("POST", "../php/insert.php", false);
    req.setRequestHeader("Content-type",
        "application/x-www-form-urlencoded");
        
    req.send("table=interests" +
             "&name="  + inter);
    
    if(parseInt(req.responseText) != 0) {
        $("#actual_data").html("<div class = 'sub_id'>int</div>");
        $("#actual_data").append(req.responseText);
        $("#actual_data").css("color", "#961c00");
        
        return;
    }
    
    $("#actual_data").css("color", "#575757");
    onIntEditButtonClicked();
}

function callEntOkContext() {
    var enter = [
        $("#ent_name").val(),
        $("#ent_address").val(),
        $("#sel_int").text(),
        $(".selected_id").text()
    ];
    
    onCanButtonClicked();
    
    for(var i = 0; i < enter.length; i++) {
        if(enter[i] == "") {
            $("#actual_data").html("<div class = 'sub_id'>ent</div>");
            $("#actual_data").append("Fields can not be empty!");
            $("#actual_data").css("color", "#961c00");
            
            return;
        }
    }
    
    if(enter[2] == "select interest") {
        $("#actual_data").html("<div class = 'sub_id'>ent</div>");
        $("#actual_data").append("Please select interest!");
        $("#actual_data").css("color", "#961c00");
        
        return;
    }
    
    var req = new XMLHttpRequest();
    req.open("POST", "../php/insert.php", false);
    req.setRequestHeader("Content-type",
        "application/x-www-form-urlencoded");
        
    req.send("table=enterprises"        +
             "&name="        + enter[0] +
             "&address="     + enter[1] + 
             "&interest_id=" + enter[3]);
    
    if(parseInt(req.responseText) != 0) {
        $("#actual_data").html("<div class = 'sub_id'>ent</div>");
        $("#actual_data").append(req.responseText);
        $("#actual_data").css("color", "#961c00");
        
        return;
    }
    
    $("#actual_data").css("color", "#575757");
    onEntEditButtonClicked();
}

function callPerOkContext() {
    var person = [
        $("#sel_ent").text(),
        $(".selected_id").text(),
    
        $("#per_surname").val(),
        $("#per_name").val(),
        $("#per_first_name").val(),
        $("#per_skype").val(),
        $("#per_mail").val(),
        $("#per_phone").val(),
    ];
    
    onCanButtonClicked();
    
    for(var i = 0; i < person.length; i++) {
        if(person[i] == "") {
            $("#actual_data").html("<div class = 'sub_id'>per</div>");
            $("#actual_data").append("Fields can not be empty!");
            $("#actual_data").css("color", "#961c00");
            
            return;
        }
    }
    
    if(person[0] == "select enterprise") {
        $("#actual_data").html("<div class = 'sub_id'>per</div>");
        $("#actual_data").append("Please select enterprise!");
        $("#actual_data").css("color", "#961c00");
        
        return;
    }
    
    var req = new XMLHttpRequest();
    req.open("POST", "../php/insert.php", false);
    req.setRequestHeader("Content-type",
        "application/x-www-form-urlencoded");
        
    req.send("table=persons"               +
             "&surname="        + person[2] +
             "&name="           + person[3] +
             "&first_name="     + person[4] +
             "&skype="          + person[5] +
             "&mail="           + person[6] +
             "&phone="          + person[7] + 
             "&enterprise_id="  + person[1]);
    
    if(parseInt(req.responseText) != 0) {
        $("#actual_data").html("<div class = 'sub_id'>per</div>");
        $("#actual_data").append(req.responseText);
        $("#actual_data").css("color", "#961c00");
        
        return;
    }
    
    $("#actual_data").css("color", "#575757");
    onPerEditButtonClicked();
}

function callConOkContext() {
    var conv = [
        $("#sel_per").text(),
        $(".selected_id").text(),
    
        $("#con_date").val(),
        $("#con_time").val(),
        $("#con_goal").val(),
        $("#con_result").val(),
    ];
    
    onCanButtonClicked();
    
    for(var i = 0; i < conv.length; i++) {
        if(conv[i] == "") {
            alert("Fields can not be empty!");
            return;
        }
    }
    
    if(conv[0] == "select person") {
        alert("Please select person!");
        return;
    }
    
    var req = new XMLHttpRequest();
    req.open("POST", "../php/insert.php", false);
    req.setRequestHeader("Content-type",
        "application/x-www-form-urlencoded");
        
    req.send("table=conversations"   +
             "&date="      + conv[2] +
             "&time="      + conv[3] +
             "&goal="      + conv[4] +
             "&result="    + conv[5] +
             "&person_id=" + conv[1]);
    
    if(parseInt(req.responseText) != 0) {
        alert(req.responseText);
        return;
    }
    
    $("#actual_data").css("color", "#575757");
    showTimeline();
}

function onOkButtonClicked() {
    var subId = $(".sub_id").text();
    
    if(subId == "int") {
        callIntOkContext();
    } else if(subId == "ent") {
        callEntOkContext();
    } else if(subId == "per") {
        callPerOkContext();
    } else {
        callConOkContext();
    }
}

function onSelButtonClicked() {
    display("#select_confirm", true);
    displayAll(false);
    $(".editor").css("display", "none");
    
    $("#select_confirm").html(
        "<br><button class = 'cat_sel_back'>BACK</button><br>");
    
    var subId = $(".sub_id").text();
    if(subId == "ent") {
        
        var inters = getTableData("interests");
        for(var i = 0; i < inters.length; i++) {
            
            var txtBlock = [
                "<div class = 'num'>",
                    inters[i]["id"],
                "</div>",
                
                "<button class = 'cat_sel'>",
                    inters[i]["name"],
                "</button><br>"
            ];
            
            $("#select_confirm").prepend(txtBlock.join(""));
        }
        
    } else if(subId == "per") {
        
        var enters = getTableData("enterprises");
        for(var i = 0; i < enters.length; i++) {
            
            var txtBlock = [
                "<div class = 'num'>",
                    enters[i]["id"],
                "</div>",
                
                "<button class = 'cat_sel'>",
                    enters[i]["name"],
                "</button><br>"
            ];
            
            $("#select_confirm").prepend(txtBlock.join(""));
        }
        
    } else {
        
        var pers = getTableData("persons");
        for(var i = 0; i < pers.length; i++) {
            
            var txtBlock = [
                "<div class = 'num'>",
                    pers[i]["id"],
                "</div>",
                
                "<button class = 'cat_sel'>",
                    pers[i]["surname"]    + " ",
                    pers[i]["name"]       + " ",
                    pers[i]["first_name"] + " ",
                "</button><br>"
            ];
            
            $("#select_confirm").prepend(txtBlock.join(""));
        }
        
    }
}

function onDelIntButtonClicked() {
    var id = $(this).prev().text();
    
    var req = new XMLHttpRequest();
    req.open("POST", "../php/delete_row.php", false);
    req.setRequestHeader("Content-type",
        "application/x-www-form-urlencoded");
        
    req.send("table=interests" +
             "&id="  + id);
    
    if(parseInt(req.responseText) != 0) {
        $("#actual_data").html("<div class = 'sub_id'>int</div>");
        $("#actual_data").append(req.responseText);
        $("#actual_data").css("color", "#961c00");
        
        return;
    }
    
    $("#actual_data").css("color", "#575757");
    onIntEditButtonClicked();
}

function onDelConButtonClicked() {
    var id = $(this).parent().prev().prev().text();
    
    var req = new XMLHttpRequest();
    req.open("POST", "../php/delete_row.php", false);
    req.setRequestHeader("Content-type",
        "application/x-www-form-urlencoded");
        
    req.send("table=conversations" +
             "&id="  + id);
    
    if(parseInt(req.responseText) != 0) {
        alert(req.responseText);
        return;
    }
    
    $("#actual_data").css("color", "#575757");
    showTimeline();
}

function onDelEntButtonClicked() {
    var id = $(this).prev().text();
    
    var req = new XMLHttpRequest();
    req.open("POST", "../php/delete_row.php", false);
    req.setRequestHeader("Content-type",
        "application/x-www-form-urlencoded");
        
    req.send("table=enterprises" +
             "&id="  + id);
    
    if(parseInt(req.responseText) != 0) {
        $("#actual_data").html("<div class = 'sub_id'>ent</div>");
        $("#actual_data").append(req.responseText);
        $("#actual_data").css("color", "#961c00");
        
        return;
    }
    
    $("#actual_data").css("color", "#575757");
    onEntEditButtonClicked();
}

function onDelPerButtonClicked() {
    var id = $(this).prev().text();
    
    var req = new XMLHttpRequest();
    req.open("POST", "../php/delete_row.php", false);
    req.setRequestHeader("Content-type",
        "application/x-www-form-urlencoded");
        
    req.send("table=persons" +
             "&id="  + id);
    
    if(parseInt(req.responseText) != 0) {
        $("#actual_data").html("<div class = 'sub_id'>per</div>");
        $("#actual_data").append(req.responseText);
        $("#actual_data").css("color", "#961c00");
        
        return;
    }
    
    $("#actual_data").css("color", "#575757");
    onPerEditButtonClicked();
}

function onCatSelBackButtonClicked() {
    display(".list_choise", false);
    display("#content", false);
    
    display("#header", true);
    display("#sub_content", true);
    
    var subId = $(".sub_id").text();
    if(subId == "int") {
        $("#int_editor").css("display", "block");
    } else if(subId == "ent") {
        $("#ent_editor").css("display", "block");
    } else if(subId == "per") {
        $("#per_editor").css("display", "block");
    } else {
        display("#content", true);
        $("#con_editor").css("display", "block");
    }
}

function onCatSelButtonClicked() {
    $(".sel_btn").text($(this).text());
    $(".selected_id").text($(this).prev().text());
    
    onCatSelBackButtonClicked();
}

$(function() {
    $("#add_menu").click(onAddMenuButtonClicked);
    $(".can_btn").click(onCanButtonClicked);
    $(".ok_btn").click(onOkButtonClicked);
    
    $(".sel_btn").click(onSelButtonClicked);
    
    $(document).on("click", ".del_int_btn", onDelIntButtonClicked);
    $(document).on("click", ".cat_sel", onCatSelButtonClicked);
    $(document).on("click", ".cat_sel_back", onCatSelBackButtonClicked);
    
    $(document).on("click", ".del_ent_btn", onDelEntButtonClicked);
    $(document).on("click", ".del_per_btn", onDelPerButtonClicked);
    $(document).on("click", ".delete_menu", onDelConButtonClicked);
    
    $(document).on("click", ".details_menu", onDetailsMenuButtonClicked);
});
