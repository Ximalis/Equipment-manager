
function onLogoutButtonClicked() {
    display("#logout_confirm", true);
    displayAll(false);
}

function onLogoutConfButtonClicked() {
    window.location.href = "../php/logout.php";
}

function onBackSpecButtonClicked() {
    display(".list_choise", false);
    displayAll(true);
    
    $("#actual_data").html("<div class = 'sub_id'>con</div>");
    showTimeline();
}

function onExportButtonClicked() {
    window.location.href = "../php/export.php";
}

function onEditButtonClicked() {
    display("#edit_confirm", true);
    displayAll(false);
    $(".editor").css("display", "none");
}

function onBackupButtonClicked() {
    display("#not_av_confirm", true);
    displayAll(false);
}

function onArchiveButtonClicked() {
    display("#not_av_confirm", true);
    displayAll(false);
}

$(function() {
    $("#logout_menu").click(onLogoutButtonClicked);
    $("#con_log_menu").click(onLogoutConfButtonClicked);
    $(".back_spec_menu").click(onBackSpecButtonClicked);
    
    $("#export_menu").click(onExportButtonClicked);
    $("#backup_menu").click(onBackupButtonClicked);
    $("#archive_menu").click(onArchiveButtonClicked);
    
    $("#edit_menu").click(onEditButtonClicked);
    $("#int_edit_menu").click(onIntEditButtonClicked);
    $("#ent_edit_menu").click(onEntEditButtonClicked);
    $("#per_edit_menu").click(onPerEditButtonClicked);
});
