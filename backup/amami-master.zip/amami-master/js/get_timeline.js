
var WEEKDAYS = [
    "SUNDAY",
    "MONDAY",
    "TUESDAY",
    "WEDNESDAY",
    "THURSDAY",
    "FRIDAY",
    "SATURDAY"
];

function creNewRecHead(newRecHeadNum, dateStr) {

    var recHeadId = "rec_head_" + newRecHeadNum;
    var date = new Date(dateStr);

    var recHead = [
        "<div class = 'record_heading'>",
            "<div class = 'num'>" + newRecHeadNum + "</div>",
            
            WEEKDAYS[date.getDay()] + ", " + dateStr + ":",

            "<div class = 'add_btn'>",
                "<button class = 'add_con_menu'>add</button>",
            "</div>",
        "</div>"
    ];

    $("#content").append(recHead.join(""));
}

function creNewRec(dataMap) {

    var newRec = [
        "<div class = 'record'>",
            "<div class = 'num'>" + dataMap["id"] + "</div>",
            "<div class = 'msg'>",
                "<div class = 'left'>",
                    "<div class = 'left_tag'>at</div>",
                    "<div class = 'left_data'>" + dataMap["time"] + "</div>",

                    "<div class = 'left_tag'>with</div>",
                    "<div class = 'left_data'>" + dataMap["name"] + "</div>",

                    "<div class = 'left_tag'>from</div>",
                    "<div class = 'left_data'>" + dataMap["enterprise"] + "</div>",
                    
                    "<div class = 'left_tag adv'>located</div>",
                    "<div class = 'left_data adv'>" + dataMap["address"] + "</div>",
                    
                    "<div class = 'right_tag adv'>result</div>",
                    "<div class = 'right_data adv'>" + dataMap["result"] + "</div>",
                "</div>",

                "<div class = 'right'>",
                    "<div class = 'left_tag'>interest</div>",
                    "<div class = 'left_data'>" + dataMap["interest"] + "</div>",

                    "<div class = 'left_tag'>goal</div>",
                    "<div class = 'left_data'>" + dataMap["goal"] + "</div>",

                    "<div class = 'left_tag'>phone</div>",
                    "<div class = 'left_data'>" + dataMap["phone"] + "</div>",
                    
                    "<div class = 'right_tag adv'>mail</div>",
                    "<div class = 'right_data adv'>" + dataMap["mail"] + "</div>",
                    
                    "<div class = 'left_tag adv'>skype</div>",
                    "<div class = 'left_data adv'>" + dataMap["skype"] + "</div>",
                "</div>",
            "</div>",

            "<div class = 'msg_tools'>",
                "<button class = 'details_menu'>details</button>",
                "<button class = 'edit_msg_menu'>edit</button>",
                "<button class = 'delete_menu'>delete</button>",
            "</div>",

            "<hr>",
        "</div>"
    ];

    $("#content").append(newRec.join(""));
}

function updateTimeline(convs, inters, 
                        enters, persons) {

    var prevDate = "";
    var zeroPerId = persons[0][""]
    
    for(var i = 0; i < convs.length; i++) {

        if(prevDate != convs[i]["date"]) {

            creNewRecHead(convs[i]["id"], convs[i]["date"]);
            prevDate = convs[i]["date"];
        }

        var perIdx = findIdxForId(persons, convs[i]["person_id"]);
        var enterIdx = findIdxForId(enters, persons[perIdx]["enterprise_id"]);
        var interIdx = findIdxForId(inters, enters[enterIdx]["interest_id"]);

        var perName = persons[perIdx]["surname"]     + " " +
                      persons[perIdx]["name"]        + " " +
                      persons[perIdx]["first_name"];
                      
        var dataMap = {
            "id"         : convs[i]["id"],
            "time"       : convs[i]["time"],
            "interest"   : inters[interIdx]["name"],
            "name"       : perName,
            "enterprise" : enters[enterIdx]["name"],
            "goal"       : convs[i]["goal"],
            "result"     : convs[i]["result"],
            "phone"      : persons[perIdx]["phone"],
            "skype"      : persons[perIdx]["skype"],
            "mail"       : persons[perIdx]["mail"],
            "address"    : enters[enterIdx]["address"]
        };

        creNewRec(dataMap);
    }
}

function showTimeline() {
    $("#content").html("");
    var convs = getTableData("conversations");

    var data = [
        "You have no planned conversations",
        "<div class = 'add_btn'>",
            "<button class = 'add_con_menu'>add</button>",
        "</div>",
    ];

    if(!convs.length){
        $("#content").append(data.join(""));
    } else {
        
        var inters = getTableData("interests");
        var enters = getTableData("enterprises");
        var persons = getTableData("persons");
        
        updateTimeline(convs, inters, 
                       enters, persons);
    }
}

$(function() {
    showTimeline();
});
