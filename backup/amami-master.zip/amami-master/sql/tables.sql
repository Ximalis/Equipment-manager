
CREATE TABLE `conversations` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `date` date NOT NULL,
    `time` time NOT NULL,
    `person_id` int(11) NOT NULL,
    `goal` text NOT NULL,
    `result` text NOT NULL,
    `user_id` int(11) NOT NULL,
    PRIMARY KEY (`id`),
    KEY `person_id` (`person_id`),
    KEY `user_id` (`user_id`)
) ENGINE = InnoDB;

CREATE TABLE `enterprises` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` text NOT NULL,
    `address` text NOT NULL,
    `interest_id` int(11) NOT NULL,
    PRIMARY KEY (`id`),
    KEY `interest_id` (`interest_id`)
) ENGINE = InnoDB;

CREATE TABLE `interests` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` text NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;

CREATE TABLE `persons` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `surname` text NOT NULL,
    `name` text NOT NULL,
    `first_name` text NOT NULL,
    `enterprise_id` int(11) NOT NULL,
    `phone` text NOT NULL,
    `mail` text NOT NULL,
    `skype` text NOT NULL,
    PRIMARY KEY (`id`),
    KEY `enterprise_id` (`enterprise_id`)
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `mail` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE = InnoDB;


ALTER TABLE `conversations`
    ADD CONSTRAINT `conversations_ibfk_1` FOREIGN KEY (`person_id`)
    REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
    
ALTER TABLE `conversations`
    ADD CONSTRAINT `conversations_ibfk_2` FOREIGN KEY (`user_id`)
    REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

ALTER TABLE `enterprises`
    ADD CONSTRAINT `enterprises_ibfk_1` FOREIGN KEY (`interest_id`)
    REFERENCES `interests` (`id`) ON UPDATE NO ACTION;

ALTER TABLE `persons`
    ADD CONSTRAINT `persons_ibfk_1` FOREIGN KEY (`enterprise_id`) 
    REFERENCES `enterprises` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
