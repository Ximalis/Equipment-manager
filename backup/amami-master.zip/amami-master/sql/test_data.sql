
INSERT INTO `interests`(`id`, `name`) VALUES (1, 'web');
INSERT INTO `interests`(`id`, `name`) VALUES (2, 'it');


INSERT INTO `enterprises`(`id`, `name`, `address`, `interest_id`) 
VALUES (1, 'Microsoft', '1414 NW Northrup Street Suite 900 Posrtland, OR 97209', 1);

INSERT INTO `enterprises`(`id`, `name`, `address`, `interest_id`) 
VALUES (2, 'Apple', '1 Infinite Loop Cupertino, CA 95014 408.996.1010', 2);


INSERT INTO `persons`(`id`, `surname`, `name`,
                      `first_name`, `enterprise_id`,
                      `phone`, `mail`, `skype`) 
VALUES (1, 'White', 'Tiffany', 'Ann', 1,
        '+380971234567', 'tiffany@jk.com', 'haha34');

INSERT INTO `persons`(`id`, `surname`, `name`,
                      `first_name`, `enterprise_id`,
                      `phone`, `mail`, `skype`) 
VALUES (2, 'Petrucci', 'John', 'Andrew', 2,
        '123-45-56', 'petr@ha.net', 'aaaa45');


INSERT INTO `conversations`(`date`, `time`, `person_id`,
                            `goal`, `result`, `user_id`)
VALUES ('2013-12-12', '14:40', 1, 'to talk about everything', '-', 2);

INSERT INTO `conversations`(`date`, `time`, `person_id`,
                            `goal`, `result`, `user_id`)
VALUES ('2013-10-11', '15:50', 1, 'to talk much', '-', 2);

INSERT INTO `conversations`(`date`, `time`, `person_id`,
                            `goal`, `result`, `user_id`)
VALUES ('2013-12-30', '12:35', 2, 'to think about sky & sun', '-', 2);

INSERT INTO `conversations`(`date`, `time`, `person_id`,
                            `goal`, `result`, `user_id`)
VALUES ('2013-10-11', '15:50', 1, 'to talk much', '-', 2);

INSERT INTO `conversations`(`date`, `time`, `person_id`,
                            `goal`, `result`, `user_id`)
VALUES ('2013-12-30', '18:35', 1, 'to think about sky & sun', '-', 2);

INSERT INTO `conversations`(`date`, `time`, `person_id`,
                            `goal`, `result`, `user_id`)
VALUES ('2013-10-11', '16:50', 2, 'to talk much', '-', 2);

INSERT INTO `conversations`(`date`, `time`, `person_id`,
                            `goal`, `result`, `user_id`)
VALUES ('2013-12-30', '17:35', 2, 'to think about sky & sun', '-', 2);






