
<?php

include_once "db_conn.php";
include_once "functions.php";
 
startSecSes();

if(!checkLogin($conn)) {
    header("Location: login.php");
}

?>

<!DOCTYPE html>
<html>
    <head>
        <link rel = "stylesheet" 
              type = "text/css"
              href = "../css/main.css">
        
        <meta charset = "utf-8">
        
        <title>AMAMI</title>
    </head>

    <body>
        <div id = "vertical">
        </div>

        <div id = "header">
            <input type = "text" 
                value = "search...">
            <hr>
            
            <button id = "add_menu" class = "txt_btn">add</button><br>
        </div>
        
        <div id = "footer">
            Designed by<br>
            Igor Cheremskyi<br>
            in Kharkiv<br>
        </div>

        <div id = "greeting">
            hi, <?php echo $_SESSION["name"]; ?>!<br>
        </div>

        <div id = "menu">
            <button id = "edit_menu">EDIT</button><br>
            <button id = "archive_menu">ARCHIVE</button><br>
            <button id = "upcom_menu" class = "back_spec_menu">UPCOMING</button><br>
            <button id = "backup_menu">BACKUP</button><br>
            <button id = "export_menu">EXPORT</button><br><br>
            
            <button id = "logout_menu">LOGOUT</button><br>
        </div>

        <div id = "logout_confirm"
             class = "list_choise">
             
            <button id = "con_log_menu">CONFIRM</button><br>
            <button class = "back_spec_menu">BACK</button><br>
        </div>
        
        <div id = "edit_confirm"
             class = "list_choise">
             
            <button id = "int_edit_menu">INTERESTS</button><br>
            <button id = "ent_edit_menu">ENTERPRISES</button><br>
            <button id = "per_edit_menu">PERSONS</button><br><br>
            <button class = "back_spec_menu">BACK</button><br>
        </div>
        
        <div id = "select_confirm"
             class = "list_choise">
        </div>
        
        <div id = "not_av_confirm"
             class = "list_choise">
             
            <button class = "back_spec_menu">
                Sorry, but this feature is not available yet :(</button><br><br>
            <button class = "back_spec_menu">BACK</button><br>
        </div>
        
        <div id = "sub_content">
            <div id = "int_editor"
                 class = "editor">
                 
                <div class = "enter">
                    <input type = "text"
                           id = "int_text"
                           value = "interest">
                    <hr>
                </div>
                
                <button class = "ok_btn txt_btn">ok</button>
                <button class = "can_btn txt_btn">cancel</button>
                
                <br><br><br><br>
            </div>
            
            <div id = "ent_editor"
                 class = "editor">
                 
                <div class = "enter">
                    <input type = "text"
                           id = "ent_name"
                           value = "name">
                    <hr>
                </div><br><br>
                
                <div class = "enter">
                    <input type = "text"
                           id = "ent_address"
                           value = "address">
                    <hr>
                </div><br><br>
                
                <div class = "num selected_id">-1</div>
                    
                <button class = "txt_btn sel_btn" id = "sel_int">select interest</button>
                <button class = "ok_btn txt_btn">ok</button>
                <button class = "can_btn txt_btn">cancel</button>
                
                <br><br><br><br>
            </div>
            
            <div id = "per_editor"
                 class = "editor">
                 
                <div class = "enter">
                    <input type = "text"
                           id = "per_surname"
                           value = "surname">
                    <hr>
                </div><br><br>
                
                <div class = "enter">
                    <input type = "text"
                           id = "per_name"
                           value = "name">
                    <hr>
                </div><br><br>
                
                <div class = "enter">
                    <input type = "text"
                           id = "per_first_name"
                           value = "first name">
                    <hr>
                </div><br><br>
                
                <div class = "enter">
                    <input type = "text"
                           id = "per_skype"
                           value = "skype">
                    <hr>
                </div><br><br>
                
                <div class = "enter">
                    <input type = "text"
                           id = "per_mail"
                           value = "mail">
                    <hr>
                </div><br><br>
                
                <div class = "enter">
                    <input type = "text"
                           id = "per_phone"
                           value = "phone">
                    <hr>
                </div><br><br>
                
                <div class = "num">-1</div>
                
                <button class = "txt_btn sel_btn" id = "sel_ent">select enterprise</button>
                <button class = "ok_btn txt_btn">ok</button>
                <button class = "can_btn txt_btn">cancel</button>
                
                <br><br><br><br>
            </div>
            
            <div id = "con_editor"
                 class = "editor">
                
                <div class = "enter">
                    <input type = "text"
                           id = "con_date"
                           value = "date">
                    <hr>
                </div><br><br>
                
                <div class = "enter">
                    <input type = "text"
                           id = "con_time"
                           value = "time">
                    <hr>
                </div><br><br>
                
                <div class = "enter">
                    <input type = "text"
                           id = "con_goal"
                           value = "goal">
                    <hr>
                </div><br><br>
                
                <div class = "enter">
                    <input type = "text"
                           id = "con_result"
                           value = "result">
                    <hr>
                </div><br><br>
                
                <div class = "num">-1</div>
                
                <button class = "txt_btn sel_btn" id = "sel_per">select person</button>
                <button class = "ok_btn txt_btn">ok</button>
                <button class = "can_btn txt_btn">cancel</button>
                
                <br>
            </div>
            
            <div id = "actual_data">
            </div>
        </div>

        <div id = "content">
        </div>
    </body>
    
    <script src = "../js/jquery-1.10.2.js"></script>
    <script src = "../js/functions.js"></script>
    <script src = "../js/get_timeline.js"></script>
    <script src = "../js/edit_menu.js"></script>
    <script src = "../js/main_menu.js"></script>
    <script src = "../js/msg_menu.js"></script>
</html>
