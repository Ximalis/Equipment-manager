
<?php

define("HOST",          "localhost");
define("USER",          "root");
define("PASSWORD",      "root");
define("DATABASE",      "amami");

define("ERR_CONN",      "Error while connecting to database!");
define("ERR_NO_USR",    "There is no such user!");
define("ERR_USR_EX",    "User with such name already exists!");
define("ERR_PASS",      "Wrong password!");
define("ERR_HTTP_Q",    "Wrong HTTP query parameters!");
define("ERR_NAME_PASS", "Wrong name or password!");
define("ERR_BAD_REG",   "Registration failed!");
define("ERR_SQL_Q",     "Error while executing sql!");

define("ERR_OK",        "0");
define("ERR_OK_REG",    "Registration succeeded!");

?>
