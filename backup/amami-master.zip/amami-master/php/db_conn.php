
<?php

include_once "defs.php";

$conn = mysqli_connect(HOST, USER, 
                       PASSWORD, 
                       DATABASE);
                         
if(!$conn) {
    die(ERR_CONN);
}

?>
