
<?php

include_once "defs.php";
include_once "functions.php";
include_once "db_conn.php";

startSecSes();

if(!isset($_POST["table"])) {
    die(ERR_SQL_Q);
}

$query = "INSERT INTO `" . $_POST["table"] . "`";

if($_POST["table"] == "interests") {
    
    $query .= "(`name`) VALUES('" . $_POST["name"] . "')";
    
} else if($_POST["table"] == "enterprises") {
    
    $query .= "(`name`, `address`, `interest_id`)" .
              " VALUES('" . $_POST["name"]          . "', '" .
                            $_POST["address"]       . "', "  .  
                            $_POST["interest_id"]   . ")";
    
} else if($_POST["table"] == "persons") {
    
    $query .= "(`surname`, `name`, `first_name`, "         .
              "`enterprise_id`, `phone`, `skype`, `mail`)" .
              " VALUES('" . $_POST["surname"]              . "', '"  .
                            $_POST["name"]                 . "', '"  . 
                            $_POST["first_name"]           . "', "   .
                            $_POST["enterprise_id"]        . ", '"   .
                            $_POST["phone"]                . "', '"  .
                            $_POST["skype"]                . "', '"  .
                            $_POST["mail"]                 . "')";
    
} else if($_POST["table"] == "conversations") {
    
    $query .= "(`date`, `time`, `person_id`, `goal`, `result`, `user_id`)" .
              " VALUES('" . $_POST["date"]                . "', '" .
                            $_POST["time"]                . "', "  . 
                            $_POST["person_id"]           . ", '"  .
                            $_POST["goal"]                . "', '" .
                            $_POST["result"]              . "', "  .
                            $_SESSION["id"]               . ")";
}

$res = mysqli_query($conn, $query);
if(!$res) {
    die(ERR_SQL_Q);
}

echo "0";

?>
