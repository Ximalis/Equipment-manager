
<?php

include_once "defs.php";

function startSecSes() {
    session_name("amami");
    session_start();
    session_regenerate_id();
}

function doLogin($name, $password, $mysqli) {
    
    $query = "SELECT `id`, `password`" .
             " FROM `users` " . 
             "WHERE `name` = '" . $name . "'";
    
    $rs = mysqli_query($mysqli, $query);
    if(!$rs) {
        die(ERR_NO_USR);
    }
    
    $row = mysqli_fetch_object($rs);
    
    if(!isset($row->password) ||
       !isset($row->id)) {
                  
        die(ERR_NO_USR);
    }
            
    if($row->password == $password) {
        
        $browser = $_SERVER["HTTP_USER_AGENT"];
        
        $_SESSION["id"] = $row->id;
        $_SESSION["name"] = $name;
        $_SESSION["hash"] = 
            hash("sha512", $row->password . $browser);
                                           
        return true;
        
    } else {
        
        die(ERR_PASS);
    }
}

function checkLogin($mysqli) {
    
    if(isset($_SESSION["id"], 
             $_SESSION["name"], 
             $_SESSION["hash"])) {

        $browser = $_SERVER["HTTP_USER_AGENT"];
        
        $query = "SELECT `name`, `password`" .
                 " FROM `users` " . "WHERE `id` = " .
                 $_SESSION["id"];
     
        $rs = mysqli_query($mysqli, $query);
        if(!$rs) {
            return false;
        }
        
        $row = mysqli_fetch_object($rs);
        if(!isset($row->password,
                  $row->name)) {
                      
            return false;
        }
        
        $hash = hash("sha512", $row->password . $browser);
        
        if($_SESSION["name"] != $row->name ||
           $_SESSION["hash"] != $hash) {
            
            return false;
        }
        
        return true;
        
    } else {
        
        return false;
    }
}

function regUser($user, $password, 
                 $mail, $mysqli) {
    
    $query = "INSERT INTO `users`".
             "(`name`, `mail`, `password`) " .
             "VALUES ('" . $user . "', '" .
             $mail . "', '" . $password . "')";

    if(!mysqli_query($mysqli, $query)) {
        die(ERR_USR_EX);
    } 
    
    return true;
}

function findIdxForId($arr, $id) {
    
    $i = 0;
    while($i < sizeof($arr)) {
        if($arr[$i]->id == $id) {
            return $i;
        }
        
        $i = $i + 1;
    }

    return -1;
}

?>
