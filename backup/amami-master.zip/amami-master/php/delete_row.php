
<?php

include_once "defs.php";
include_once "functions.php";
include_once "db_conn.php";

startSecSes();

if(!isset($_POST["table"],
          $_POST["id"])) {
    die(ERR_SQL_Q);
}

$query = "DELETE FROM `" . $_POST["table"] . 
         "` WHERE `id` = " . $_POST["id"];

$res = mysqli_query($conn, $query);
if(!$res) {
    die(ERR_SQL_Q);
}

echo "0";

?>
