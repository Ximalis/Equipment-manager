
<?php

include_once "db_conn.php";
include_once "functions.php";

startSecSes();
 
if(isset($_POST["name"], $_POST["passwd"])) {
    
    $name = $_POST["name"];
    $password = $_POST["passwd"];
 
    if(doLogin($name, $password, $conn) == true) {
        echo ERR_OK;
    } else {
        echo ERR_NAME_PASS;
    }
    
} else {
    echo ERR_HTTP_Q;
}

?>
