
<?php

include_once "defs.php";
include_once "functions.php";
include_once "db_conn.php";

startSecSes();

$query = "SELECT * FROM `conversations` " .
         "WHERE `user_id` = " . $_SESSION["id"] .
         " ORDER BY date(`date`)";

$convs = mysqli_query($conn, $query);
if(!$convs) {
    die(ERR_SQL_Q);
}

$query = "SELECT `id`, `surname`, `name`, `first_name` " . 
         "FROM `persons`";

$pers = mysqli_query($conn, $query);
if(!$pers) {
    die(ERR_SQL_Q);
}
         
$data = "id,date,time,surname,name,first name,goal,result\n";
$fileName = "../csv/" . date("c") . ".csv";

while($obj = mysqli_fetch_object($pers)) {
    $persons[] = $obj;
}

var_dump($persons);

while($obj = mysqli_fetch_object($convs)) {
    $idx = findIdxForId($persons, $obj->person_id);
    
    $data .= $obj->id                   . "," .
             $obj->date                 . "," .
             $obj->time                 . "," .
             $persons[$idx]->surname    . "," .
             $persons[$idx]->name       . "," .
             $persons[$idx]->first_name . "," .
             $obj->goal                 . "," .
             $obj->result               . "\n";
}

file_put_contents($fileName, $data);
header("Location: " . $fileName);

?>
