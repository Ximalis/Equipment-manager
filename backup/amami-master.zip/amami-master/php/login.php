
<?php

include_once "db_conn.php";
include_once "functions.php";
 
startSecSes();

if(checkLogin($conn)) {
    header("Location: main.php");
}

?>

<!DOCTYPE html>
<html>
    <head>
        <link rel = "stylesheet" 
              type = "text/css"
              href = "../css/main.css">
              
        <link rel = "stylesheet" 
              type = "text/css"
              href = "../css/login.css">
        
        <meta charset = "utf-8">
        
        <title>AMAMI</title>
    </head>

    <body>
        <div id = "vertical">
        </div>
        
        <div id = "footer">
            Designed by<br>
            Igor Cheremskyi<br>
            in Kharkiv<br>
        </div>

        <div id = "login_menu">
            <button id = "log_menu">LOGIN</button><br>
            <button id = "reg_menu">REGISTER</button><br>
        </div>
        
        <div id = "log_info">
        </div>
        
        <div id = "login_part"
             class = "log">
             
            <div class = "left">
                <div class = "left_tag">name</div>
                
                <div class = "enter">
                    <input type = "text"
                           id = "log_name">
                    <hr>
                </div>
            </div>
            
            <div class = "right">
                <div class = "right_tag">password</div>
                
                <div class = "enter">
                    <input type = "password"
                           id = "log_pass">
                    <hr>
                </div>
            </div>
        </div>
        
        <div id = "reg_part"
             class = "log">
             
            <div class = "left">
                <div class = "left_tag">name</div>
                <div class = "enter">
                    <input type = "text"
                           id = "reg_name">
                    <hr>
                </div>
                
                <div class = "left_tag">mail</div>
                <div class = "enter">
                    <input type = "text"
                           id = "reg_mail">
                    <hr>
                </div>
            </div>
            
            <div class = "right">
                <div class = "right_tag">password</div>
                <div class = "enter">
                    <input type = "password"
                           id = "reg_pass">
                    <hr>
                </div>
                
                <div class = "right_tag">confirm</div>
                <div class = "enter">
                    <input type = "password"
                           id = "reg_conf">
                    <hr>
                </div>
            </div>
        </div>
    </body>
    
    <script src = "../js/jquery-1.10.2.js"></script>
    <script src = "../js/login.js"></script>
    <script src = "../js/sha512.js"></script>
</html>
