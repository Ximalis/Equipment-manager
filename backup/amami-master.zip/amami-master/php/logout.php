
<?php

include_once "functions.php";

startSecSes();

$_SESSION = array();
session_destroy();

header("Location: main.php");

?>
