
<?php

include_once "db_conn.php";
include_once "functions.php";

startSecSes();

if(isset($_POST["name"], 
         $_POST["passwd"],
         $_POST["mail"])) {
    
    $name = $_POST["name"];
    $password = $_POST["passwd"];
    $mail = $_POST["mail"];
 
    if(regUser($name, $password, 
               $mail, $conn)) {
                   
        echo ERR_OK_REG;
    } else {
        echo ERR_BAD_REG;
    }
    
} else {
    
    echo ERR_HTTP_Q;
}

?>
