
<?php

include_once "defs.php";
include_once "functions.php";
include_once "db_conn.php";

startSecSes();

if(!isset($_GET["name"])) {
    die(ERR_HTTP_Q);
}

$query = "SELECT * FROM `" . $_GET["name"] . "`";

if($_GET["name"] == "conversations") {
    $query = "SELECT * FROM `conversations` " .
             "WHERE `user_id` = " . $_SESSION["id"] .
             " ORDER BY date(`date`)";
}

$rs = mysqli_query($conn, $query);
if(!$rs) {
    die(ERR_SQL_Q);
}

while($obj = mysqli_fetch_object($rs)) {
    $arr[] = $obj;
}

echo json_encode($arr, JSON_NUMERIC_CHECK);

?>
